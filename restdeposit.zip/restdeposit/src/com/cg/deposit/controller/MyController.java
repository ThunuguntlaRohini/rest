package com.cg.deposit.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.deposit.service.ICustomerService;



@CrossOrigin(origins = "http://localhost:8082")
@RestController
public class MyController {
	@Autowired
	ICustomerService service;
	
	@RequestMapping(value ="/customer/deposit/id/{id}/amount/{amount}",headers="Accept=application/json",method = RequestMethod.GET)
	public double deposit(@PathVariable("id") int id,@PathVariable("amount") double amount) {

		double balance=service.deposit(id, amount);
		return balance;

	}
}
