package com.cg.deposit.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.deposit.bean.Customer;


@Repository("dao")
public class CustomerDaoImpl implements ICustomerDao {

	@PersistenceContext
	EntityManager em;
	@Override
	public  double deposit(int id, double amount) {
		Customer customer=em.find(Customer.class, id);
		double balance=0;
		balance=customer.getBalance()+amount;
		customer.setBalance(balance);
	
		em.getTransaction().begin();
		em.merge(customer);
			
		em.getTransaction().commit();
		
		return balance;
		
	}

}
